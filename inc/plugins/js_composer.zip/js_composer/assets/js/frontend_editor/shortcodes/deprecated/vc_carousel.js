(function ( $ ) {
	window.InlineShortcodeView_vc_carousel = window.InlineShortcodeView_vc_images_carousel.extend( {} );
})( window.jQuery );